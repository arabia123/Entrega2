//NUEVO

import { useState } from "react"
import Note from "./Note.jsx";
import NoteEditor from "./NoteEditor.jsx";
import "../estilo/NoteList.css";



function NoteList (){

    const [tasks, setTasks] = useState([]); //Tendremos un array de objetos

    const addTask = (task) => {
        //trim() quita los espacios del principio y final.
        if(task.title.trim()){
            task.title = task.title.trim();
            const updatedTasks = [task, ...tasks];
            setTasks(updatedTasks);
        }
        if(task.text.trim()){
            task.text = task.text.trim();
            const updatedTasks = [task, ...tasks];
            setTasks(updatedTasks);
        }
       
    }
    


    const deleteTask = (id) => {
        const updatedTasks = tasks.filter(task => task.id !== id);
        setTasks(updatedTasks);
    }

    return (
    
        <>
        <NoteEditor className= "container-NotaEditor" onSubmit = {addTask}/>

    
        {tasks.map ((task) => 
            <Note className= "container-Nota"
                key = {task.id}
                id = {task.id}
                title = {task.title}
                text = {task.text}
                deleteNote={deleteTask}
            />
        )
        }

        </>

    );

}

export default NoteList;