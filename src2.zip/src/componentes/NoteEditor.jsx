//NUEVO

import { v4 as uuidv4 } from 'uuid'; //nos da una ip distinta cada vez
import { useState, useEffect } from 'react';
import "../estilo/NoteEditor.css"

function NoteEditor({onSubmit}){ //aqui metemos los elementos que usamos "las props"

    const [input1, setInput1] = useState('');//cada vez que escribamos actualizamos el valor de imput titulo
    const [input2, setInput2] = useState('');//cada vez que escribamos actualizamos el valor de imput texto
    const [searchTerm, setSearchTerm] = useState('');
    const [storedTasks, setStoredTasks] = useState([]);


    useEffect(() => {
        // Cargar las notas almacenadas al iniciar la aplicación
        const storedTasks = JSON.parse(localStorage.getItem("notes")) || [];
        setStoredTasks(storedTasks);
    }, []);

    
    const handleChange1 = (content) => { //mantenemos el valor en la variable
        setInput1(content.target.value);
    }

    const handleChange2 = (content) => { //mantenemos el valor en la variable
        setInput2(content.target.value);
    }

    const handleSend = (content) => { //enviamos el texto
        content.preventDefault(); //no recarga la pagina
        const newTask = {
            //genera un id unico llamando a uuidv4
            id: uuidv4(),
            title: input1,
            text: input2
        }
        
        onSubmit(newTask) //onSubmit es una prop

    }

    const handleSend2 = () => {

        const updatedTasks = [newTask, ...storedTasks];
        setStoredTasks(updatedTasks);
        localStorage.setItem("notes", JSON.stringify(updatedTasks));

        onSubmit(updatedTasks)
    }

    const filteredTasks = storedTasks.filter(
    (task) =>
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.text.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (

        <>
        <form className="form-busqueda" onSubmit={handleSend2}>

            <h1 className='aplicacionNota'>Aplicación de Notas</h1> 

            <div className="input-group input-group-sm mb-3">
                <span className="input-group-text" id="inputGroup-sizing-sm">Buscar</span>
                <input 
                    type="text" 
                    className="form-control" 
                    aria-label="Busqueda"
                    aria-describedby="basic-addon1"
                    placeholder = "nota"
                    name = "busqueda"
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <button className="button-nota">
                Enviar
            </button>

        </form>
        <form className="form-nota" onSubmit={handleSend}>

            <h2 className='insertarNota'>Insertar Nota</h2>

            <div className="input-group input-group-sm mb-3">
                <span className="input-group-text" id="inputGroup-sizing-sm">Titulo</span>
                <input 
                    type="text" 
                    className="form-control" 
                    aria-label="Título"
                    aria-describedby="basic-addon1"
                    placeholder = "Titulo"
                    name = "title"
                    onChange = {handleChange1}
                />
            </div>
            
            <input
                className="input-nota"
                type='text'
                placeholder = "nota"
                name = "text"
                onChange = {handleChange2}
            />

            <button className="button-nota">
                Guardar
            </button>

        </form>
        </>
    );
}

export default NoteEditor